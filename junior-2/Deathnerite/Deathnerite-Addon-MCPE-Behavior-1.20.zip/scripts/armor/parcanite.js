
export default {
    id: "heavy:parcanite",
    Head: {
        command: "effect @s mining_fatigue 0 0 true",
        lore: [ "§r§4+1 Tireless" ]
    },
    Chest: {
        command: "effect @s wither 0 0 true",
        lore: [ "§r§4+1 Wither Immunity" ]
    },
    Legs: {
        command: "effect @s darkness 0 0 true",
        lore: [ "§r§4+1 Darkness Mastery" ]
    },
    Feet: {
        command: "effect @s slowness 0 0 true",
        lore: [ "§r§4+1 Unstoppable" ]
    }
}