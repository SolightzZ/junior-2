import Parcanite from "./parcanite";

const ArmorSlotEnum = {
    Head: "helmet",
    Chest: "chestplate",
    Legs: "leggings",
    Feet: "boots"
}

export {
    Parcanite,
    ArmorSlotEnum
}