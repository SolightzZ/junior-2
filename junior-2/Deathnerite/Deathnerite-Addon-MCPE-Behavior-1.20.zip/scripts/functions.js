import { EntityEquippableComponent, EntityInventoryComponent } from "@minecraft/server";
import { ArmorSlotEnum } from "./armor/exports";

function hasEquipment(player, equipmentSlot, itemIdentifier) {
    const playerEquipmentComponent = player.getComponent(EntityEquippableComponent.componentId);
    const itemStack = playerEquipmentComponent.getEquipment(equipmentSlot);

    if (!itemStack || itemStack?.typeId != itemIdentifier) return false;
    return true;
}

function findItemsWithId(player, itemIdentifier) {
    const playerInventoryContainer = player.getComponent(EntityInventoryComponent.componentId).container;
    const items = [];

    for (let slot = 0; slot < playerInventoryContainer.size; slot++) {
        const itemStack = playerInventoryContainer.getItem(slot);

        if (!itemStack || itemStack?.typeId != itemIdentifier) continue;
        items.push({ slot, itemStack });
    }
    return items;
}

function getArmorItemIdentifier(itemPrefix, armorSlot) {
    return `${itemPrefix}_${ArmorSlotEnum[armorSlot]}`;
}

export {
    hasEquipment,
    getArmorItemIdentifier,
    findItemsWithId
}