import { system, world, EntityInventoryComponent, EntityEquippableComponent } from "@minecraft/server";
import { Parcanite } from "./armor/exports";
import { findItemsWithId, getArmorItemIdentifier, hasEquipment } from "./functions";

system.runInterval(() => {
    for (const player of world.getPlayers()) {
        for (const equipmentSlot of Object.keys(Parcanite).slice(1)) {
            const itemOptions = Parcanite[equipmentSlot];
            const playerInventoryContainer = player.getComponent(EntityInventoryComponent.componentId).container;
            const playerEquipmentComponent = player.getComponent(EntityEquippableComponent.componentId);
            
            // Inventory ---
            findItemsWithId(player, getArmorItemIdentifier(Parcanite.id, equipmentSlot))
            .map(found => {
                found.itemStack.setLore(itemOptions.lore);
                playerInventoryContainer.setItem(found.slot, found.itemStack);
            });
            
            // Equipment ---
            if (!hasEquipment(player, equipmentSlot, getArmorItemIdentifier(Parcanite.id, equipmentSlot))) continue;
            itemOptions?.command ? player.runCommandAsync(itemOptions.command) : null;
            itemOptions?.effect ? player.addEffect(itemOptions.effect.id, itemOptions.effect.duration, itemOptions.effectOptions): null;
            
            if (!itemOptions.lore) continue;
            const armorItemStack = playerEquipmentComponent.getEquipment(equipmentSlot);

            armorItemStack.setLore(itemOptions.lore);
            playerEquipmentComponent.setEquipment(equipmentSlot, armorItemStack);
        }
    }
}, 0);
