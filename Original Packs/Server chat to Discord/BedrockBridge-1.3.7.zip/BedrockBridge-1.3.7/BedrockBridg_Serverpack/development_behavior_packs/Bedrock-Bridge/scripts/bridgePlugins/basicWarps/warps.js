// add your warp locations in here. Don't forget the commas between one warp and another.

export const warps = {
    "fly_die": [0, 300, 0, "overworld"],
    "end_die": [0, 300, 0, "theEnd"]
}