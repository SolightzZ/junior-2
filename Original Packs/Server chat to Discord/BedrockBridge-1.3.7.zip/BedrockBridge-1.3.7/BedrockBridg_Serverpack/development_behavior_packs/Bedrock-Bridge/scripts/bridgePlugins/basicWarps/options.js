export const options = {
    "cooldown": 5, // cooldown in seconds
}