Chat Rank - Bridge Plugin v1.0.0

In order to install this bridge-plugin do the following:
- Paste this folder inside "behavior_packs/Bedrock-Bridge/scripts/bridgePlugins" 
- Edit the file called "index.js", you need to add a new line with the following text

	import "./chatRank/main"

Now it's all setup, restart your server or run the /reload command.

Settings: You can edit a few features of this plugin directly from settings.js